package vo;

public class DiagnosisVO {
	private int ill_idx;
	private String ill_name, ill_des;
	
	public int getIll_idx() {
		return ill_idx;
	}
	public void setIll_idx(int ill_idx) {
		this.ill_idx = ill_idx;
	}
	public String getIll_name() {
		return ill_name;
	}
	public void setIll_name(String ill_name) {
		this.ill_name = ill_name;
	}
	public String getIll_des() {
		return ill_des;
	}
	public void setIll_des(String ill_des) {
		this.ill_des = ill_des;
	}
}
