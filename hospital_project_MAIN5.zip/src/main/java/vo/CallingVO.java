package vo;

public class CallingVO {
	public int calling_idx, calling_chk;
	public String calling_name, calling_tel;
	
	public int getCalling_idx() {
		return calling_idx;
	}
	public void setCalling_idx(int calling_idx) {
		this.calling_idx = calling_idx;
	}
	public int getCalling_chk() {
		return calling_chk;
	}
	public void setCalling_chk(int calling_chk) {
		this.calling_chk = calling_chk;
	}
	public String getCalling_name() {
		return calling_name;
	}
	public void setCalling_name(String calling_name) {
		this.calling_name = calling_name;
	}
	public String getCalling_tel() {
		return calling_tel;
	}
	public void setCalling_tel(String calling_tel) {
		this.calling_tel = calling_tel;
	}

}
