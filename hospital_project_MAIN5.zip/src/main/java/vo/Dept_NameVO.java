package vo;

public class Dept_NameVO {

}
